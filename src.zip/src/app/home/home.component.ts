import { Component, OnInit } from '@angular/core';
import { UserService } from '../_services/user.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  imageUnifespLogo = 'https://www.unifesp.br/reitoria/dci/images/docs/manual_da_marca/Unifesp_completa_verde_negativo_RGB.png';
  content?: string;
  constructor(private userService: UserService) {}
  ngOnInit(): void {
    this.userService.getPublicContent().subscribe(
      (data) => {
        this.content = data;
      },
      (err) => {
        this.content = JSON.parse(err.error).message;
      }
    );
  }
}
